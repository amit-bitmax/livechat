import React from 'react'

const AdmintAppbar = () => {
  return (
    <div>AdmintAppbar</div>
  )
}

export default AdmintAppbar;