import React from 'react'

const QaAppbar = () => {
  return (
    <div>QaAppbar</div>
  )
}

export default QaAppbar