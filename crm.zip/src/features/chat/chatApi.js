import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

export const chatApi = createApi({
  reducerPath: 'chatApi',
  baseQuery: fetchBaseQuery({
    baseUrl: 'http://localhost:5003/api/v1/chatmessage',
    prepareHeaders: (headers) => {
      const token = localStorage.getItem('token');
      if (token) headers.set('Authorization', `Bearer ${token}`);
      return headers;
    }
  }),
  tagTypes: ['Chat'],
  endpoints: (builder) => ({
    sendMessage: builder.mutation({
      query: ({ to, message }) => ({
        url: '/send',
        method: 'POST',
        body: { to, message }
      }),
      invalidatesTags: ['Chat']
    }),
    getConversation: builder.query({
      query: (otherId) => `/conversation/${otherId}`,
      providesTags: ['Chat']
    }),
    getAllCustomer: builder.query({
      query: () => '/all'
    })
  })
});

export const {useGetAllCustomerQuery, useSendMessageMutation, useGetConversationQuery } = chatApi;
