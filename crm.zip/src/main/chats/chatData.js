const chatData = [
    {
        id: 1,
        username: "Amit Kumar",
        employeeId: "EMP001",
        mobile: "9876543210",
        email: "amit@example.com",
        status: "Active",
        message:"How are your?",
        onBreak: false,
        activeSince: "2025-07-10T07:30:00Z",
        elapsedTime: 0,
    },
    {
        id: 2,
        username: "Neha Verma",
        employeeId: "EMP002",
        mobile: "9988776655",
        email: "neha@example.com",
        status: "On Break",
        message:"Good Morning",
        activeSince: "2025-07-12T07:30:00Z",
        elapsedTime: 0,
        onBreak: false
    },
    {
        id: 3,
        username: "Rahul Singh",
        employeeId: "EMP003",
        mobile: "9123456780",
        email: "rahul@example.com",
        status: "Active",
         message:"Hello, Good Morning!",
        activeSince: "2025-07-13T07:10:58Z",
        elapsedTime: 0,
        onBreak: true
    },

];

export { chatData }; 