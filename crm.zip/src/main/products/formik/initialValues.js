export const productInitialValues = {
    name: '',
    description: '',
    brand: '',
    categoryId: '',
    color: '',
    model: '',
    price: '',
    discount: '',
    reviews: '',
    rating: '',
    size: '',
    productImage: null
};
